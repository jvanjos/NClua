--[[Inicializacão Padrão]]
local tests = require ('tests')
local ASSERT = tests.ASSERT
local ASSERT_ERROR = tests.ASSERT_ERROR
local TRACE = tests.trace
local TRACE_SEP = tests.trace_sep
--[[Testes que o ASSERT retorna true]]
TRACE_SEP()
TRACE(ASSERT(bit32.arshift(50,2)))
TRACE_SEP()
TRACE(ASSERT(bit32.band(6544778+6,654)))
TRACE_SEP()
TRACE(ASSERT(bit32.bnot(124)))
TRACE_SEP()
TRACE(ASSERT(bit32.bor(17,64)))
TRACE_SEP()
TRACE(ASSERT(bit32.btest(78,10)))
TRACE_SEP()
TRACE(ASSERT(bit32.bxor(35,96)))
TRACE_SEP()
TRACE(ASSERT(bit32.extract(6544,4,5)))
TRACE_SEP()
TRACE(ASSERT(bit32.replace(210,21,0)))
TRACE_SEP()
TRACE(ASSERT(bit32.lrotate(47,2)))
TRACE_SEP()
TRACE(ASSERT(bit32.lshift(6,30)))
TRACE_SEP()
TRACE(ASSERT(bit32.rrotate(46,46)))
TRACE_SEP()
TRACE(ASSERT(bit32.rshift(01,132)))
--[[Testes em que o ASSERT retorna false]]
TRACE(ASSERT(bit32.btest(78,-79)))
TRACE(ASSERT(bit32.arshift(33,uahasoash)))
TRACE(ASSERT(bit32.bor(errors)))


