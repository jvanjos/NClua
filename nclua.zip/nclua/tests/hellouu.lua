local assert = assert
local hello = require ('nclua.event.hello')

hello:check {class='hello'}
