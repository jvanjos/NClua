export GST_DEBUG="nclua:DEBUG";
export GST_PLUGIN_PATH="/home/osboxes/Desktop/nclua/lib/.libs";
export G_DEBUG="all";
export G_SLICE="always-malloc";
export LD_LIBRARY_PATH="/home/osboxes/Desktop/nclua/lib/.libs:/home/osboxes/Desktop/nclua/nclua:/home/osboxes/Desktop/nclua/nclua/event";
export LUA_CPATH="/home/osboxes/Desktop/nclua/tests/.libs/?.so;/home/osboxes/Desktop/nclua/?.so;;";
export LUA_PATH="/home/osboxes/Desktop/nclua/?.lua;/home/osboxes/Desktop/nclua/?/init.lua;/home/osboxes/Desktop/nclua/tests/?.lua;;";
export MALLOC_CHECK_=1;

