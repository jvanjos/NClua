#include <config.h>
#include "aux-glib.h"
#include "aux-lua.h"
#include <gio/gio.h>

#include "callback.h"

typedef struct{
  char *oi;        /* client socket handle */
} texto;


static inline texto*
uDataCheck (lua_State *L, int index, char **input)
{
  texto *text;
  text = (texto *) luaL_checkudata (L, index, "nclua.event.hello_teste");
  tryset (input, text->oi);
  return text;
}

static int
texto_new (lua_State *L){
	texto *text;
	text = (texto *) luaL_newuserdata (L, sizeof (*text));
	g_assert_nonnull (text);
	text->oi = "hello";
	luax_dump_stack(L);
	luaL_setmetatable (L,"nclua.event.hello_teste");
	return 1;
}
static const struct luaL_Reg text_func[] = {
  {"hello", texto_new}
};

int event (lua_State *L);

int
event(lua_State *L){
  lua_newtable (L);
  luax_newmetatable (L, "nclua.event.hello_teste");
  luaL_setfuncs (L, text_func, 0);
  return 1;
}
