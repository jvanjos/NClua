local hello

local assert = assert
local pcall = pcall
local type = type

local check = require ('nclua.event.check')
local engine = require ('nclua.event.engine')
local hello_test = require ('nclua.event.hello_test')
_ENV = nil

do
   hello = engine:new ()
   hello.class = 'hello'
end

local ola = hello_testo.new () 

local status, errmsg = pcall (hello_text.text_new,
                                       ola,
				       evt.method:upper (),
                                       evt.uri,
                                       evt.headers or {},
                                       evt.body or '',
                                       request_finished,
                                       evt.timeout)


function hello:check (evt)
   if assert (evt.class == hello.class) then
      print("Esse lixo aki!")
   end
end
